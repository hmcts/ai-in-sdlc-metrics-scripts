const { readBlob } = require('../runAllMetrics/blobStorage');

module.exports = async function(context, req) {
  try {
    const raw = await readBlob('output/weeklyData.json');
    context.res = {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: raw
    };
  } catch (err) {
    context.log.error('getMetrics failed:', err.message);
    context.res = { status: 500, body: { error: err.message } };
  }
};

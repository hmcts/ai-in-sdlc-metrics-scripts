const https = require('https');
const { readBlob, writeBlob } = require('./blobStorage');

const CUTOVER_DATE = '2026-02-02'; // Week 18 — JIRA decommissioned, switch to GitHub Projects
const ORG = 'hmcts';
const PROJECT_NUMBER = 43;

// ─── Week generation ──────────────────────────────────────────────────────────
function generateWeeks() {
  const PROJECT_START = '2025-10-07';
  const MONTH_ABBR = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  function padded(n) { return String(n).padStart(2, '0'); }
  function formatDate(d) { return `${d.getFullYear()}-${padded(d.getMonth()+1)}-${padded(d.getDate())}`; }
  function formatPeriod(s, e) {
    const start = `${MONTH_ABBR[s.getMonth()]} ${s.getDate()}`;
    if (s.getMonth() === e.getMonth()) return `${start}-${e.getDate()}`;
    return `${start}-${MONTH_ABBR[e.getMonth()]} ${e.getDate()}`;
  }
  const today = new Date(); today.setHours(23, 59, 59, 999);
  const weeks = [];
  let weekStart = new Date(PROJECT_START);
  const daysToFriday = (5 - weekStart.getDay() + 7) % 7;
  let weekEnd = new Date(weekStart); weekEnd.setDate(weekEnd.getDate() + daysToFriday);
  let weekNum = 1;
  while (weekStart <= today) {
    weeks.push({ name: `Week ${weekNum}`, start: formatDate(weekStart), end: formatDate(weekEnd), period: formatPeriod(weekStart, weekEnd) });
    weekNum++;
    weekStart = new Date(weekEnd); weekStart.setDate(weekStart.getDate() + 3);
    weekEnd = new Date(weekStart); weekEnd.setDate(weekEnd.getDate() + 4);
  }
  return weeks;
}

// ─── NK/T helpers ─────────────────────────────────────────────────────────────
function calculateBusinessDays(startDate, endDate) {
  let count = 0;
  const current = new Date(startDate);
  while (current <= new Date(endDate)) {
    const day = current.getDay();
    if (day !== 0 && day !== 6) count++;
    current.setDate(current.getDate() + 1);
  }
  return count;
}

function calculateNKT(prDates) {
  if (!prDates || prDates.length === 0) return { nkt: null, cycleTime: null };
  const cycleTimes = prDates.filter(pr => pr.mergedAt).map(pr => calculateBusinessDays(new Date(pr.createdAt), new Date(pr.mergedAt)));
  const avgCycleTime = cycleTimes.length > 0 ? cycleTimes.reduce((a, b) => a + b, 0) / cycleTimes.length : null;
  const N = 13, K = 1, T = avgCycleTime || 1;
  return { nkt: parseFloat(((N * K) / T).toFixed(2)), cycleTime: avgCycleTime ? parseFloat(avgCycleTime.toFixed(2)) : null };
}

// ─── GitHub GraphQL helper ────────────────────────────────────────────────────
function githubGraphQL(query, variables) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({ query, variables });
    const req = https.request({
      hostname: 'api.github.com',
      path: '/graphql',
      method: 'POST',
      headers: {
        Authorization: `Bearer ${process.env.GITHUB_TOKEN}`,
        'User-Agent': 'empirical-metrics-bot',
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body)
      }
    }, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        if (res.statusCode !== 200) return reject(new Error(`GraphQL ${res.statusCode}: ${data.slice(0, 200)}`));
        try { resolve(JSON.parse(data)); } catch (e) { reject(e); }
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

// ─── GitHub Projects estimates ────────────────────────────────────────────────
async function fetchProjectEstimates(context) {
  // Step 1: get project node ID
  const idResult = await githubGraphQL(`
    query($org: String!, $num: Int!) {
      organization(login: $org) {
        projectV2(number: $num) { id }
      }
    }`, { org: ORG, num: PROJECT_NUMBER });

  const projectId = idResult.data?.organization?.projectV2?.id;
  if (!projectId) throw new Error('Could not find GitHub Project #' + PROJECT_NUMBER);
  context.log(`  GitHub Project node ID: ${projectId}`);

  // Step 2: paginate through all items
  const vibeMap = {};   // 'VIBE-145' -> estimate
  const issueMap = {};  // 47 -> estimate
  let cursor = null;

  do {
    const result = await githubGraphQL(`
      query($id: ID!, $cursor: String) {
        node(id: $id) {
          ... on ProjectV2 {
            items(first: 100, after: $cursor) {
              pageInfo { hasNextPage endCursor }
              nodes {
                content { ... on Issue { number title labels(first: 10) { nodes { name } } } }
                fieldValueByName(name: "Estimate") {
                  ... on ProjectV2ItemFieldNumberValue { number }
                }
              }
            }
          }
        }
      }`, { id: projectId, cursor });

    const items = result.data?.node?.items;
    if (!items) break;

    for (const node of items.nodes) {
      const issue = node.content;
      const estimate = node.fieldValueByName?.number;
      if (!issue || estimate == null) continue;

      issueMap[issue.number] = estimate;

      // Index by VIBE ID — check title first, then jira:VIBE-XXX labels
      const titleMatch = (issue.title || '').match(/([A-Z]+-\d+)/);
      if (titleMatch) {
        vibeMap[titleMatch[1]] = estimate;
      } else {
        const labels = issue.labels?.nodes || [];
        for (const label of labels) {
          const labelMatch = label.name.match(/^jira:([A-Z]+-\d+)$/);
          if (labelMatch) { vibeMap[labelMatch[1]] = estimate; break; }
        }
      }
    }

    cursor = items.pageInfo.hasNextPage ? items.pageInfo.endCursor : null;
  } while (cursor);

  context.log(`  Project estimates loaded: ${Object.keys(issueMap).length} issues, ${Object.keys(vibeMap).length} with VIBE IDs`);
  return { vibeMap, issueMap };
}

// ─── Main ─────────────────────────────────────────────────────────────────────
async function collect(context) {
  context.log('--- Story Points / NK/T metrics ---');

  const githubRaw = await readBlob('output/github.json');
  if (!githubRaw) throw new Error('output/github.json not found in blob — run github.js first');
  const githubData = JSON.parse(githubRaw);

  const weeks = generateWeeks();

  // Fetch GitHub Projects estimates once for all post-cutover weeks
  let vibeMap = {}, issueMap = {};
  const hasPostCutover = weeks.some(w => w.start >= CUTOVER_DATE);
  if (hasPostCutover) {
    try {
      ({ vibeMap, issueMap } = await fetchProjectEstimates(context));
    } catch (err) {
      context.log(`  WARNING: Could not fetch GitHub Project estimates: ${err.message}`);
    }
  }

  const jiraMetrics = [];

  for (let i = 0; i < weeks.length; i++) {
    const week = weeks[i];
    const githubWeek = githubData.weeks[i] || {};
    const prDates = githubWeek.prDates || [];
    const nktData = calculateNKT(prDates);

    if (week.start < CUTOVER_DATE) {
      // Pre-cutover: JIRA is gone, SP preserved via merge.js fallback
      jiraMetrics.push({ week: week.name, period: week.period, storyPoints: null, wipSP: null, nkt: nktData.nkt, cycleTime: nktData.cycleTime });
      context.log(`  ${week.name}: pre-cutover (SP preserved from history), NK/T: ${nktData.nkt ?? 'N/A'}`);
    } else {
      // Post-cutover: match via GitHub Projects
      const prTickets = githubWeek.prTickets || [];          // VIBE IDs from PR titles
      const prIssueNumbers = githubWeek.prIssueNumbers || []; // issue numbers from PR bodies

      let storyPoints = 0;
      for (const vibeId of prTickets) {
        if (vibeMap[vibeId] != null) storyPoints += vibeMap[vibeId];
      }
      for (const issueNum of prIssueNumbers) {
        if (issueMap[issueNum] != null) storyPoints += issueMap[issueNum];
      }

      jiraMetrics.push({ week: week.name, period: week.period, storyPoints: storyPoints || null, wipSP: null, nkt: nktData.nkt, cycleTime: nktData.cycleTime });
      context.log(`  ${week.name}: ${storyPoints || 'N/A'} SPs, NK/T: ${nktData.nkt ?? 'N/A'}`);
    }
  }

  await writeBlob('output/jira.json', { weeks: jiraMetrics, vibeMap, issueMap });
  context.log('  ✓ output/jira.json written');
}

module.exports = { collect };

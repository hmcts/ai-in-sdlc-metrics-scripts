const https = require('https');
const crypto = require('crypto');

const ACCOUNT = process.env.AZURE_STORAGE_ACCOUNT || 'empiricalmetrics';
const KEY = process.env.AZURE_STORAGE_KEY;
const CONTAINER = process.env.AZURE_STORAGE_CONTAINER || 'claude-transcripts';

// ─── Shared Key auth ──────────────────────────────────────────────────────────
function buildAuth(method, blobPath, queryParams, extraHeaders, contentLength, contentType, date) {
  const dateStr = date.toUTCString();
  const version = '2020-10-02';

  const allHeaders = { 'x-ms-date': dateStr, 'x-ms-version': version, ...extraHeaders };
  const canonicalHeaders = Object.keys(allHeaders).filter(k => k.startsWith('x-ms-')).sort()
    .map(k => `${k}:${allHeaders[k]}`).join('\n') + '\n';

  const resourcePath = `/${ACCOUNT}/${CONTAINER}${blobPath ? '/' + blobPath : ''}`;
  const sortedParams = queryParams
    ? Object.keys(queryParams).sort().map(k => `${k}:${queryParams[k]}`).join('\n')
    : '';
  const canonicalResource = resourcePath + (sortedParams ? '\n' + sortedParams : '');

  const stringToSign = [
    method,
    '',                        // Content-Encoding
    '',                        // Content-Language
    contentLength != null ? String(contentLength) : '',
    '',                        // Content-MD5
    contentType || '',
    '',                        // Date (empty — use x-ms-date)
    '', '', '', '', '',        // If-* headers + Range
    canonicalHeaders + canonicalResource
  ].join('\n');

  const key = Buffer.from(KEY, 'base64');
  const sig = crypto.createHmac('sha256', key).update(stringToSign, 'utf8').digest('base64');
  return { ...allHeaders, Authorization: `SharedKey ${ACCOUNT}:${sig}` };
}

function httpsRequest(options, body) {
  return new Promise((resolve, reject) => {
    const req = https.request(options, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, body: Buffer.concat(chunks).toString('utf8') }));
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

// ─── Public API ───────────────────────────────────────────────────────────────
async function readBlob(blobPath) {
  const date = new Date();
  const headers = buildAuth('GET', blobPath, null, {}, null, null, date);
  const res = await httpsRequest({
    hostname: `${ACCOUNT}.blob.core.windows.net`,
    path: `/${CONTAINER}/${blobPath}`,
    method: 'GET',
    headers
  });
  if (res.status === 404) return null;
  if (res.status !== 200) throw new Error(`readBlob(${blobPath}) → ${res.status}: ${res.body.slice(0, 200)}`);
  return res.body;
}

async function writeBlob(blobPath, content) {
  const body = typeof content === 'string' ? content : JSON.stringify(content, null, 2);
  const buf = Buffer.from(body, 'utf8');
  const contentType = 'application/json';
  const date = new Date();
  const headers = buildAuth('PUT', blobPath, null, { 'x-ms-blob-type': 'BlockBlob' }, buf.length, contentType, date);
  const res = await httpsRequest({
    hostname: `${ACCOUNT}.blob.core.windows.net`,
    path: `/${CONTAINER}/${blobPath}`,
    method: 'PUT',
    headers: { ...headers, 'Content-Type': contentType, 'Content-Length': buf.length }
  }, buf);
  if (res.status !== 201) throw new Error(`writeBlob(${blobPath}) → ${res.status}: ${res.body.slice(0, 200)}`);
}

async function listBlobs(prefix) {
  const date = new Date();
  const queryParams = { comp: 'list', prefix, restype: 'container' };
  const qs = Object.entries(queryParams).map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&');
  const headers = buildAuth('GET', '', queryParams, {}, null, null, date);
  const res = await httpsRequest({
    hostname: `${ACCOUNT}.blob.core.windows.net`,
    path: `/${CONTAINER}?${qs}`,
    method: 'GET',
    headers
  });
  if (res.status !== 200) throw new Error(`listBlobs(${prefix}) → ${res.status}: ${res.body.slice(0, 200)}`);

  const blobs = [];
  for (const match of res.body.matchAll(/<Blob>([\s\S]*?)<\/Blob>/g)) {
    const block = match[1];
    const name = (block.match(/<Name>([^<]+)<\/Name>/) || [])[1];
    const size = parseInt((block.match(/<Content-Length>([^<]+)<\/Content-Length>/) || [])[1] || '0');
    const lastModified = (block.match(/<Last-Modified>([^<]+)<\/Last-Modified>/) || [])[1];
    if (name) blobs.push({ name, size, lastModified });
  }
  return blobs;
}

module.exports = { readBlob, writeBlob, listBlobs };

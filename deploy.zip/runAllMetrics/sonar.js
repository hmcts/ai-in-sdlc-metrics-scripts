const { execSync } = require('child_process');
const { readBlob, writeBlob } = require('./blobStorage');

const PROJECT_KEY = 'hmcts.cath';
const SONAR_METRICS = ['coverage','vulnerabilities','sqale_rating','reliability_rating','security_rating','bugs','code_smells','duplicated_lines_density'];

// ─── Week generation ──────────────────────────────────────────────────────────
function generateWeeks() {
  const PROJECT_START = '2025-10-07';
  const MONTH_ABBR = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  function padded(n) { return String(n).padStart(2, '0'); }
  function formatDate(d) { return `${d.getFullYear()}-${padded(d.getMonth()+1)}-${padded(d.getDate())}`; }
  function formatPeriod(s, e) {
    const start = `${MONTH_ABBR[s.getMonth()]} ${s.getDate()}`;
    if (s.getMonth() === e.getMonth()) return `${start}-${e.getDate()}`;
    return `${start}-${MONTH_ABBR[e.getMonth()]} ${e.getDate()}`;
  }
  const today = new Date(); today.setHours(23, 59, 59, 999);
  const weeks = [];
  let weekStart = new Date(PROJECT_START);
  const daysToFriday = (5 - weekStart.getDay() + 7) % 7;
  let weekEnd = new Date(weekStart); weekEnd.setDate(weekEnd.getDate() + daysToFriday);
  let weekNum = 1;
  while (weekStart <= today) {
    weeks.push({ name: `Week ${weekNum}`, start: formatDate(weekStart), end: formatDate(weekEnd), period: formatPeriod(weekStart, weekEnd) });
    weekNum++;
    weekStart = new Date(weekEnd); weekStart.setDate(weekStart.getDate() + 3);
    weekEnd = new Date(weekStart); weekEnd.setDate(weekEnd.getDate() + 4);
  }
  return weeks;
}

// ─── SonarCloud API ───────────────────────────────────────────────────────────
function fetchSonarHistory(context) {
  const token = process.env.SONAR_TOKEN;
  if (!token) { context.log('  ⚠ SONAR_TOKEN not set'); return null; }
  try {
    const url = `https://sonarcloud.io/api/measures/search_history?component=${PROJECT_KEY}&branch=master&metrics=${SONAR_METRICS.join(',')}&ps=500`;
    const response = execSync(`curl -s -u "${token}:" "${url}"`, { encoding: 'utf8' });
    const data = JSON.parse(response);
    return data.measures || null;
  } catch (e) {
    context.log(`  ⚠ SonarCloud fetch failed: ${e.message}`);
    return null;
  }
}

function getSonarMetricsForWeek(measures, week) {
  if (!measures) return null;
  const weekEnd = new Date(week.end); weekEnd.setHours(23, 59, 59, 999);
  const result = {};
  for (const measure of measures) {
    const candidates = (measure.history || []).filter(h => new Date(h.date) <= weekEnd);
    result[measure.metric] = candidates.length ? parseFloat(candidates[candidates.length - 1].value) : null;
  }
  return Object.values(result).some(v => v !== null) ? result : null;
}

// ─── Preserved data fallback ──────────────────────────────────────────────────
async function loadPreservedSonarData() {
  const sonarFields = ['testCoverage','cves','duplicatedLines','maintainability','reliability','security','bugs','codeSmells'];
  const bestData = {};
  try {
    const raw = await readBlob('output/sonar.json');
    if (raw) {
      const source = JSON.parse(raw).weeks || [];
      for (const entry of source) {
        if (!entry.week) continue;
        if (!bestData[entry.week]) bestData[entry.week] = {};
        for (const field of sonarFields) {
          if (entry[field] != null && bestData[entry.week][field] == null) bestData[entry.week][field] = entry[field];
        }
      }
    }
  } catch { /* no preserved data yet */ }
  return bestData;
}

// ─── Main ─────────────────────────────────────────────────────────────────────
async function collect(context) {
  context.log('--- SonarCloud metrics ---');
  const measures = fetchSonarHistory(context);
  const preserved = await loadPreservedSonarData();
  const sonarMetrics = [];

  for (const week of generateWeeks()) {
    const raw = getSonarMetricsForWeek(measures, week);
    const p = preserved[week.name] || {};
    const metrics = {
      testCoverage:    (raw?.coverage                ?? null) ?? p.testCoverage    ?? null,
      cves:            (raw?.vulnerabilities           ?? null) ?? p.cves            ?? null,
      duplicatedLines: (raw?.duplicated_lines_density  ?? null) ?? p.duplicatedLines ?? null,
      maintainability: (raw?.sqale_rating              ?? null) ?? p.maintainability ?? null,
      reliability:     (raw?.reliability_rating        ?? null) ?? p.reliability     ?? null,
      security:        (raw?.security_rating           ?? null) ?? p.security        ?? null,
      bugs:            (raw?.bugs                      ?? null) ?? p.bugs            ?? null,
      codeSmells:      (raw?.code_smells               ?? null) ?? p.codeSmells      ?? null
    };
    sonarMetrics.push({ week: week.name, period: week.period, ...metrics });
  }

  await writeBlob('output/sonar.json', { weeks: sonarMetrics });
  context.log('  ✓ output/sonar.json written');
}

module.exports = { collect };

const github     = require('./github');
const sonar      = require('./sonar');
const transcript = require('./transcript');
const jira       = require('./jira');
const merge      = require('./merge');

module.exports = async function (context, timer) {
  if (timer.isPastDue) context.log('Timer is past due — running now');

  context.log('='.repeat(60));
  context.log('COLLECTING METRICS — ' + new Date().toISOString());
  context.log('='.repeat(60));

  try {
    await github.collect(context);
    await sonar.collect(context);
    await transcript.collect(context);
    await jira.collect(context);
    await merge.collect(context);
    context.log('='.repeat(60));
    context.log('ALL METRICS COMPLETE');
    context.log('='.repeat(60));
  } catch (error) {
    context.log.error('Metrics collection failed:', error.message);
    throw error;
  }
};
